﻿using System.Collections;
using UnityEngine;

[System.Serializable]
public class GameData
{
    public RoundData[] allRoundData;
}
