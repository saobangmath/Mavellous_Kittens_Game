﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerProgress
{
    public int highestScore = 0;
}
